package com.base.Service;

public interface StudentService {

}
