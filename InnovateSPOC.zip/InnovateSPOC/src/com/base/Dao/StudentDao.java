package com.base.Dao;

public interface StudentDao {

}
