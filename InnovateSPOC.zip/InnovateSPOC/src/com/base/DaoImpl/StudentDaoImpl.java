package com.base.DaoImpl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.base.Dao.StudentDao;

@Repository("StudentDao")
public class StudentDaoImpl implements StudentDao{
	 @Autowired
	 private SessionFactory sessionFactory;

}