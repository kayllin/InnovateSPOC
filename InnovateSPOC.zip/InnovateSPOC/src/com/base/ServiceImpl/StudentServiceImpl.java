package com.base.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.base.Dao.StudentDao;
import com.base.Service.StudentService;

@Service("StudentService")
public class StudentServiceImpl implements StudentService {

	@Autowired
    private StudentDao studentdao;
}